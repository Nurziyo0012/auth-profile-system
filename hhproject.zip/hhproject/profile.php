<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit;
}

$conn = new mysqli("localhost", "root", "", "myproject");

// Get current user data
$user_id = $_SESSION['user_id'];
$query = $conn->prepare("SELECT name, phone, email FROM users WHERE id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<h2>Welcome, <?= htmlspecialchars($user['name']) ?>!</h2>

<form action="update_profile.php" method="POST">
  <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">  
  <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required><br>
  <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required><br>
  <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br>
  <input type="password" name="new_password" placeholder="New password (optional)"><br>
  <button type="submit">Update</button>
</form>