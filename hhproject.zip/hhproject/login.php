<?php
session_start(); // remember the user

$conn = new mysqli("localhost", "root", "", "myproject");

// Taking data
$login = $_POST['login'];
$password = $_POST['password'];

// find by base (phone or email)
$stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ? OR phone = ?");
$stmt->bind_param("ss", $login, $login);
$stmt->execute();
$result = $stmt->get_result();

// if user found check
if ($user = $result->fetch_assoc()) {
    // verify password
    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        echo "🎉 Wellcome, " . $user['name'] . "!";
        // Instance: header('Location: profile.php');
    } else {
        echo "❌ Password not correct!";
    }
} else {
    echo "⚠️ User not found!";
}
?>