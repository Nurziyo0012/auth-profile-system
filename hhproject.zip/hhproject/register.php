<?php
$conn = new mysqli("localhost", "root", "", "myproject");


$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirm = $_POST['confirm'];


if ($password !== $confirm) {
  die("Passwords not same!");
}


$check = $conn->prepare("SELECT id FROM users WHERE phone = ? OR email = ?");
$check->bind_param("ss", $phone, $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
  die("This phone or email already registered");
}


$hashed = password_hash($password, PASSWORD_DEFAULT);


$insert = $conn->prepare("INSERT INTO users (name, phone, email, password) VALUES (?, ?, ?, ?)");
$insert->bind_param("ssss", $name, $phone, $email, $hashed);
$insert->execute();

echo "Registered!";




?>